package net.web2018group22.lab;

public class NotificationError {
    public static final String NOTI_ERR_FIRSTNAME = "Tên không đúng    ";
    public static final String NOTI_ERR_LASTNAME = "Họ không đúng";
    public static final String NOTI_ERR_EMAIL = "Điền lại Email của bạn";
    public static final String NOTI_ERR_PHONE = "Số điện thoại không tồn tại";
    public static final String NOTI_ERR_PASS = "Sai mật khẩu";
    public static final String NOTI_ERR_BIRTHDAY = "Vui lòng chọn sinh nhật của bạn";

}
