package net.web2018group22.lab;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/formhandlinglab3")
public class formhandlinglab3 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //get attributes of input
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String email = request.getParameter("email");
        String phonenumber = request.getParameter("phonenumber");
        String pass = request.getParameter("pass");
        String retypepass = request.getParameter("retypepass");
        String birthday = request.getParameter("birthday");
        String gender = request.getParameter("gender");
        //
        HttpSession session = request.getSession();
        String url = "/login/signupsuccessfully.jsp";
        if (CheckInput.checkFirstName(firstname) == false) {
            url = "/login/signup.jsp";
            session.setAttribute("firstname", NotificationError.NOTI_ERR_FIRSTNAME);
        }

        if (CheckInput.checkLastName(lastname) == false) {
            url = "/login/signup.jsp";
            session.setAttribute("lastname", NotificationError.NOTI_ERR_LASTNAME);
        }

        if (CheckInput.checkEmail(email) == false) {
            url = "/login/signup.jsp";
            session.setAttribute("email", NotificationError.NOTI_ERR_EMAIL);
        }
        if (CheckInput.checkPhoneNumber(phonenumber) == false) {
            url = "/login/signup.jsp";
            session.setAttribute("phone", NotificationError.NOTI_ERR_PHONE);
        }
        if (CheckInput.checkPassword(pass, retypepass) == false) {
            url = "/login/signup.jsp";
            session.setAttribute("password", NotificationError.NOTI_ERR_PASS);
        }

        if (CheckInput.checkBirthday(birthday) == false) {
            url = "/login/signup.jsp";
            session.setAttribute("birthday", NotificationError.NOTI_ERR_BIRTHDAY);
        }

        Account account = new Account(firstname, lastname, email, phonenumber, pass, birthday, gender);

        session.setAttribute("Account", account);

        RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher(url);
        requestDispatcher.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
}
