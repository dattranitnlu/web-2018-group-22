package net.web2018group22.lab;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/signupsuccessfullylab2")
public class signupsuccessfullylab2 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String email = request.getParameter("email");
        String phonenumber = request.getParameter("phonenumber");
        String pass = request.getParameter("pass");
        String retypepass = request.getParameter("retypepass");
        String birthday = request.getParameter("birthday");
        String optradio = request.getParameter("optradio");

        PrintWriter out = response.getWriter();
        out.println(firstname);
        out.println(lastname);
        out.println(email);
        out.println(phonenumber);
        out.println(pass);
        out.println(birthday);
        out.println(optradio);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
}
