package net.web2018group22.model;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

	public static List<Product> listProduct;

	public static List<Product> getListProduct() {
		if (listProduct == null)
			listProduct = new ArrayList<>();/* Khởi tạo listProduct */
		if (listProduct.size() == 0) {
			/* Thêm các Product vào danh sách bằng cách nhập thủ công */
			listProduct.add(new Product(2312, "Apple Macbook MMGM2 12inch (Vàng Hồng) - Hàng nhập khẩu",
					"img/apple/mmgm2.jpg", 37460000, 16));
			listProduct.add(new Product(2313, "Laptop Asus X55UA-XX036D 15.6inch (Đen) - Hàng chính hãng",
					"img/asus/x55ua-xx036d.jpg", 11400000, 8));
			listProduct.add(new Product(2314, "Laptop Asus Intel core i5 6300HQ VGA 4G GL552VX-DM143D...",
					"img/asus/g1552vx-dm143d.jpg", 20770000, 16));
		}
		return listProduct;
	}

	public static String showProduct(Product p) {
		return "<tr><td>" + p.getId() + "</td><td>" + p.getName()
				+ " <span class=\"label label-info\">Mới</span></td><td><img class=\"img-thumbnails colxs-3\" src=\"img/noigm.jpg\"></td><td>"
				+ p.getPrice() + "</td><td>"
				+ new DecimalFormat("#.0").format((p.getPrice() - (p.getPrice() * (p.getPerSale() / 100))))
				+ "</td><td><button type=\"button\" class=\"btn btn-success btnsm\">Xóa</button></td></tr>";
	}

}
