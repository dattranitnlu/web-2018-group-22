package login;

public class Account {
	public static String firstname;
	public static String lastname;
	public static String email;
	public static String phonenumber;
	public static String pass;
	public static String birthday;
	public static String gender;

	public static String getFirstname() {
		return firstname;
	}

	public static void setFirstname(String firstname) {
		Account.firstname = firstname;
	}

	public static String getLastname() {
		return lastname;
	}

	public static void setLastname(String lastname) {
		Account.lastname = lastname;
	}

	public static String getEmail() {
		return email;
	}

	public static void setEmail(String email) {
		Account.email = email;
	}

	public static String getPhonenumber() {
		return phonenumber;
	}

	public static void setPhonenumber(String phonenumber) {
		Account.phonenumber = phonenumber;
	}

	public static String getPass() {
		return pass;
	}

	public static void setPass(String pass) {
		Account.pass = pass;
	}

	public static String getBirthday() {
		return birthday;
	}

	public static void setBirthday(String birthday) {
		Account.birthday = birthday;
	}

	public static String getGender() {
		return gender;
	}

	public static void setGender(String gender) {
		Account.gender = gender;
	}

	@Override
	public String toString() {
		return firstname + " " + lastname + "\n" + email + " \n" + phonenumber + "\n" + pass + "\n" + birthday + "\n"
				+ gender + "\n";
	}
}
