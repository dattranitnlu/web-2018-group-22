package login;


public class NotificationError {
    public static final String NOTI_ERR_FIRSTNAME = "Tên không đúng    ";
    public static final String NOTI_ERR_LASTNAME = "Họ không đúng";
    public static final String NOTI_ERR_EMAIL = "nhập lại Email của bạn";
    public static final String NOTI_ERR_PHONE = "Số điện thoại không tồn tại";
    public static final String NOTI_ERR_PASS = "Sai mật khẩu";
    public static final String NOTI_ERR_BIRTHDAY = "Vui lòng chọn ngày sinh của bạn";

}
