package login;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckInput {

    public static boolean checkFirstName(String firstname) {
        return (firstname == null || firstname.equals("")) ? false : true;
    }

    public static boolean checkLastName(String lastname) {
        return (lastname == null || lastname.equals("")) ? false : true;
    }

    public static boolean checkEmail(String email) {
        return (email == null || email.equals("") || !email.contains("@")) ? false : true;
    }

    public static boolean checkPhoneNumber(String phoneNumber) {
        Pattern pattern = Pattern.compile("^[0-9]*$");
        Matcher matcher = pattern.matcher(phoneNumber);
        if (!matcher.matches()) {
            return false;
        } else if (phoneNumber.length() == 10 || phoneNumber.length() == 11) {
            if (phoneNumber.length() == 10) {
                if (phoneNumber.substring(0, 2).equals("09")) {
                    return true;
                } else {
                    return false;
                }
            } else if (phoneNumber.substring(0, 2).equals("01")) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static boolean checkPassword(String password, String retypePassword) {
        return (password == "" || retypePassword == "" || password == null || retypePassword == null || !password.equals(retypePassword)) ? false : true;
    }

    public static boolean checkBirthday(String birthday) {
        return (birthday == null || birthday == "") ? false : true;
    }


}
