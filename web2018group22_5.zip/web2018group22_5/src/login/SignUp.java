package login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SignUp
 */
@WebServlet("/login/SignUp")
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SignUp() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		String phonenumber = request.getParameter("phonenumber");
		String pass = request.getParameter("pass");
		String retypepass = request.getParameter("retypepass");
		String birthday = request.getParameter("birthday");
		String gender = request.getParameter("gender");
		String url = "/login/signupsuccessfully.jsp";
		
		if (CheckInput.checkFirstName(firstname) == false) {
			url = "/login/signup.jsp";
			request.setAttribute("firstname", NotificationError.NOTI_ERR_FIRSTNAME);
		}

		if (CheckInput.checkLastName(lastname) == false) {
			url = "/login/signup.jsp";
			request.setAttribute("lastname", NotificationError.NOTI_ERR_LASTNAME);
		}

		if (CheckInput.checkEmail(email) == false) {
			url = "/login/signup.jsp";
			request.setAttribute("email", NotificationError.NOTI_ERR_EMAIL);
		}
		if (CheckInput.checkPhoneNumber(phonenumber) == false) {
			url = "/login/signup.jsp";
			request.setAttribute("phone", NotificationError.NOTI_ERR_PHONE);
		}
		if (CheckInput.checkPassword(pass, retypepass) == false) {
			url = "/login/signup.jsp";
			request.setAttribute("password", NotificationError.NOTI_ERR_PASS);
		}

		if (CheckInput.checkBirthday(birthday) == false) {
			url = "/login/signup.jsp";
			request.setAttribute("birthday", NotificationError.NOTI_ERR_BIRTHDAY);
		}

		Account.setFirstname(firstname);
		Account.setBirthday(birthday);
		Account.setEmail(email);
		Account.setLastname(lastname);
		Account.setGender(gender);
		Account.setPass(pass);
		Account.setPhonenumber(phonenumber);
		RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher(url);
		requestDispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
